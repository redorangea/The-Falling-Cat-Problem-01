extends Area2D

@export_file("*.tscn") var next_room: String


func _on_body_entered(body):
	if body.is_in_group("player"):
		get_tree().change_scene_to_file(next_room)
